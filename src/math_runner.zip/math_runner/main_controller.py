#------------------------------------------------------------------------------#

from PySide6.QtGui     import QPalette, QPixmap, QUndoGroup, QUndoStack, QFont, QFontDatabase, QColor
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox, QVBoxLayout, QColorDialog, QPlainTextEdit
from PySide6.QtCore    import Qt, QTimer

from pathlib import Path
from io      import BytesIO

from meta import MetaWorld, save_meta
from meta.meta_world import MetaImage
from meta.meta_scoreboard import MetaScoreboard
from meta.math_function import EvalFunctionError

from . import parameters
from . import tools
from . import undo_commands as undo

from .main_model    import MainModel
from .object_widget import ObjectWidget
from .plot_velocity import PlotVelocity
from .plot_track    import PlotTrack
from .audio_manager import AudioManager
from .scoreboard_dialog import ScoreboardDialog


#------------------------------------------------------------------------------#
class MainController:

    path_resources = Path(__file__).parents[1]/'examples/resources'
    path_games = Path(__file__).parents[1]/'games'

    #--------------------------------------------------------------------------#
    def __init__(self, window):

        self.win = window
        self.ui  = window.ui

        self.model = MainModel(self)
        self.audio_manager = AudioManager()
        self.meta = MetaScoreboard()

        color = self.win.palette().color(QPalette.Window)

        self.plot_velocity = PlotVelocity(
            self.ui.plotVelocity,
            color,
            self.model.get_velocity_function()
        )
        self.plot_track= PlotTrack(
            self.ui.plotBoundary,
            color,
            self.model.get_boundary_functions()
        )


        # Criação do Undo Group
        self.undo_group = QUndoGroup(self.win)

        # Criação das pilhas de Undo
        self.undo_stacks = []
        for i in range(self.ui.tabWidget_Game.count()):
            self.undo_stacks.append(QUndoStack(self.win))
            self.undo_group.addStack(self.undo_stacks[i])
        self.undo_group.setActiveStack(self.undo_stacks[0])

        self.init_objects()

        self.last_dir  = str(parameters.games_path)
        self.file_name = ''

        self.start_new()

        self.update_data()

        self.connect_signals_and_slots()

        # Criação das pilhas de Undo
        self.undo_stacks = []
        for i in range(self.ui.tabWidget_Game.count()):
            self.undo_stacks.append(QUndoStack(self.win))
            self.undo_group.addStack(self.undo_stacks[i])
            if self.ui.tabWidget_Game.tabText(i) == "Velocidade":
             self.undo_stacks[i].indexChanged.connect(self.update_velocity_undo)
            if self.ui.tabWidget_Game.tabText(i) == "Borda":
                self.undo_stacks[i].indexChanged.connect(self.update_tracks_undo)
        self.undo_group.setActiveStack(self.undo_stacks[0])

    #--------------------------------------------------------------------------#
    def init_objects(self):

        #--- Obstacles --------------------------------------------------------#

        self.obstacles_area = self.ui.scrollArea_Obstacles
        self.obstacles_box  = self.obstacles_area.findChild(QVBoxLayout)
        self.num_obstacles  = 0
        self.obstacles      = []

        #--- Collectibles -----------------------------------------------------#

        self.collectibles_area = self.ui.scrollArea_Collectibles
        self.collectibles_box  = self.collectibles_area.findChild(QVBoxLayout)
        self.num_collectibles  = 0
        self.collectibles      = []

    #--------------------------------------------------------------------------#
    def connect_signals_and_slots(self):

        ui = self.ui
        #--- Menu signals -----------------------------------------------------#

        ui.action_New     .triggered.connect( self.new     )
        ui.action_Open    .triggered.connect( self.open    )
        self.ui.action_Save.triggered.connect(self.save)
        self.ui.action_Save.setEnabled(True)
        ui.action_Save_as .triggered.connect( self.save_as )
        ui.action_Exit    .triggered.connect( self.exit    )
        # ui.action_Undo    .triggered.connect( self.undo    )
        self.ui.action_Undo.triggered.connect(self.undo_group.undo)
        self.ui.action_Redo.triggered.connect(self.undo_group.redo)

        self.ui.action_Undo.setEnabled(True)
        self.ui.action_Redo.setEnabled(True)


        self.ui.menuEdit.addAction(self.ui.action_Undo)
        self.ui.menuEdit.addAction(self.ui.action_Redo)

        # ui.action_Redo    .triggered.connect( self.redo    )
        # ui.action_Reset   .triggered.connect( self.reset   )
        ui.action_Run     .triggered.connect( self.run     )
        ui.action_Build   .triggered.connect( self.build   )
        ui.action_About   .triggered.connect( self.about   )
        ui.action_Contents.triggered.connect( self.help    )


        #--- Game Tab signals -------------------------------------------------#

        ui.lineEdit_GameName.editingFinished.connect(lambda: self.change_text(ui.lineEdit_GameName))
        ui.lineEdit_Author  .editingFinished.connect(lambda: self.change_text(ui.lineEdit_Author))
        ui.plainTextEdit_GameDescription.focusOutEvent = lambda event:(self.change_plainText(ui.plainTextEdit_GameDescription, description="Alterar descrição"),
        QPlainTextEdit.focusOutEvent(ui.plainTextEdit_GameDescription, event))

        ui.pushButton_IconSelect.clicked.connect(lambda: self.select_image("icons",self.ui.label_GameIcon))

        ui.radioButton_HorizontalScrolling.toggled.connect(lambda: self.select_checked(self.ui.radioButton_VerticalScrolling))
        ui.radioButton_VerticalScrolling.toggled.connect(lambda: self.select_checked(self.ui.radioButton_HorizontalScrolling))
        ui.checkBox_TrackMaximumKills.stateChanged.connect(lambda value: self.select_checked(self.ui.checkBox_TrackMaximumKills))
        ui.checkBox_TrackMinimumKills.stateChanged.connect(lambda value: self.select_checked(self.ui.checkBox_TrackMinimumKills))
        ui.doubleSpinBox_ScoreTimeBonus.valueChanged.connect(lambda value: self.select_value(self.ui.doubleSpinBox_ScoreTimeBonus))

        #ui.pushButton_AmbienceSoundSelect.clicked.connect(self.select_ambience_sound)
        #ui.pushButton_AmbienceSoundRemove.clicked.connect(self.ambience_remove)
        #ui.pushButton_AmbienceSoundPlay.clicked.connect( self.ambience_play )
        #ui.doubleSpinBox_AmbienceSoundVolume.valueChanged.connect(lambda value: self.select_value(self.ui.doubleSpinBox_AmbienceSoundVolume))

        #--- Appearance Tab signals -------------------------------------------#

        ui.pushButton_SelectBackgroundImage.clicked.connect(lambda: self.select_image("backgrounds",self.ui.label_BackgroundImage))

        ui.checkBox_BackgroundImageScrolls.stateChanged.connect(lambda value: self.select_checked(self.ui.checkBox_BackgroundImageScrolls))

        ui.checkBox_DrawTrack.stateChanged.connect(lambda value: self.select_checked(self.ui.checkBox_DrawTrack))

        ui.pushButton_SelectTrackImage.clicked.connect(lambda: self.select_image("backgrounds", self.ui.label_TrackImage))

        ui.pushButton_SelectScoreboardImage.clicked.connect(lambda: self.select_image_with_spinbox("scoreboards", self.ui.label_ScoreboardImage, self.ui.spinBox_ScoreboardImageWidth, self.ui.spinBox_ScoreboardImageHeight))
        ui.spinBox_ScoreboardImagePositionX.valueChanged.connect(lambda value: self.select_value(self.ui.spinBox_ScoreboardImagePositionX))
        ui.spinBox_ScoreboardImagePositionY.valueChanged.connect(lambda value: self.select_value(self.ui.spinBox_ScoreboardImagePositionY))
        ui.pushButton.clicked.connect(self.configure_scoreboard_text)
        ui.spinBox_ScoreboardImageWidth.valueChanged.connect(lambda: self.select_value_spinbox(self.ui.spinBox_ScoreboardImageWidth, self.ui.spinBox_ScoreboardImageHeight, self.ui.label_ScoreboardImage, self.ui.checkBox_ScoreboardImageKeepAspectRatio))
        ui.spinBox_ScoreboardImageHeight.valueChanged.connect(lambda: self.select_value_spinbox(self.ui.spinBox_ScoreboardImageWidth, self.ui.spinBox_ScoreboardImageHeight, self.ui.label_ScoreboardImage, self.ui.checkBox_ScoreboardImageKeepAspectRatio))
        ui.checkBox_ScoreboardImageKeepAspectRatio.stateChanged.connect(lambda: self.select_keep_aspect(self.ui.checkBox_ScoreboardImageKeepAspectRatio, self.ui.spinBox_ScoreboardImageHeight))
        # ui.spinBox_ScoreboardTextPositionX
        # ui.spinBox_ScoreboardTextPositionY
        # ui.spinBox_ScoreboardTextWidth
        # ui.spinBox_ScoreboardTextHeight
        # ui.pushButton_ChoseScoreboardBgColor
        # ui.pushButton_ChoseScoreboardFgColor

        #--- Objects Tab signals ----------------------------------------------#

        ui.pushButton_NewObstacle   .clicked.connect(self.new_obstacle_widget   )
        ui.pushButton_NewCollectible.clicked.connect(self.new_collectible_widget)

        ui.doubleSpinBox_ObstaclesFrequency.   valueChanged.connect(lambda: self.select_value(self.ui.doubleSpinBox_ObstaclesFrequency))
        ui.doubleSpinBox_CollectiblesFrequency.valueChanged.connect(lambda: self.select_value(self.ui.doubleSpinBox_CollectiblesFrequency))

        ui.pushButton_SelectPlayerImage.clicked.connect(lambda: self.select_image_with_spinbox("icons", self.ui.label_PlayerImage, self.ui.spinBox_PlayerWidth, self.ui.spinBox_PlayerHeight))
        ui.spinBox_PlayerWidth.valueChanged.connect(lambda: self.select_value_spinbox(self.ui.spinBox_PlayerWidth, self.ui.spinBox_PlayerHeight, self.ui.label_PlayerImage, self.ui.checkBox_PlayerKeepAspectRatio))
        ui.spinBox_PlayerHeight.valueChanged.connect(lambda: self.select_value_spinbox(self.ui.spinBox_PlayerWidth, self.ui.spinBox_PlayerHeight, self.ui.label_PlayerImage, self.ui.checkBox_PlayerKeepAspectRatio))
        ui.checkBox_PlayerKeepAspectRatio.stateChanged.connect(lambda: self.select_keep_aspect(self.ui.checkBox_PlayerKeepAspectRatio, self.ui.spinBox_PlayerHeight))

        ui.spinBox_PlayerSpeed.valueChanged.connect(lambda value: self.select_value(self.ui.spinBox_PlayerSpeed))

        #--- Velocity and Boundary Tabs signals -------------------------------#

        ui.lineEdit_FunctionVelocity    .editingFinished.connect(self.function_velocity_changed     )
        ui.lineEdit_FunctionTrackMinimum.editingFinished.connect(self.function_track_minimum_changed)
        ui.lineEdit_FunctionTrackMaximum.editingFinished.connect(self.function_track_maximum_changed)

        # Reset scales buttons (from UI)
        try:
            ui.pushButton_ResetVelocityScales.clicked.connect(self.on_reset_velocity_scales)
        except Exception:
            pass
        try:
            ui.pushButton_ResetBoundaryScales.clicked.connect(self.on_reset_boundary_scales)
        except Exception:
            pass

        ui.tabWidget_Game.currentChanged.connect(self.update_undo_stack)

    #--------------------------------------------------------------------------#
    # Actions
    #--------------------------------------------------------------------------#

    def update_undo_stack(self, index):
        self.undo_group.setActiveStack(self.undo_stacks[index])

    #--------------------------------------------------------------------------#
    def on_reset_velocity_scales(self) -> None:
        try:
            self.plot_velocity.reset_scales()
        except Exception as e:
            print("Failed to reset velocity scales:", e)

    #--------------------------------------------------------------------------#
    def on_reset_boundary_scales(self) -> None:
        try:
            self.plot_track.reset_scales()
        except Exception as e:
            print("Failed to reset boundary scales:", e)

    #--------------------------------------------------------------------------#
    def new(self):

        if not self.confirm_deletion():
            return

        self.file_name = ''
        self.start_new()

    #--------------------------------------------------------------------------#
    def open(self):
        fname = self.get_open_fname(
            'Choose a game description',
            self.last_dir,
            'game'
        )

        if fname:
            # TODO try:
            self.file_name = fname
            self.model.open(self.file_name)

            self.clear_stacks_undo()
            self.start_view_from_model()
            self.update_data()

    #--------------------------------------------------------------------------#
    def save(self):
        meta = MetaWorld()

        #dados de texto
        meta.soft_name = self.ui.lineEdit_GameName.text()
        meta.soft_author = self.ui.lineEdit_Author.text()
        meta.soft_description = self.ui.plainTextEdit_GameDescription.toPlainText()

        #Som ambiente
        if hasattr(self, 'ambience_sound_file'):
            try:
                with open(self.ambience_sound_file, "rb") as f:
                    meta.game_ambience = f.read()
                meta.game_ambience_volume = 0.7
            except Exception as e:
                self.error_box("Erro", f"Falha ao carregar som de ambiente:\n{e}")

         # --- Fonte em bytes ---
        font_path = getattr(self, "scoreboard_font_path", None)
        if font_path:
            meta.scoreboard.text_font = tools.font_file_to_bytes(font_path)
        else:
            meta.scoreboard.text_font = None


        # --- Estilo do texto ---
        meta.scoreboard.text_font_size = int(getattr(self, "scoreboard_font_size", self.meta.text_font_size or 14))
        meta.scoreboard.text_spacing = float(getattr(self, "scoreboard_text_spacing", 1.2))
        meta.scoreboard.text_fgcolor = tools.qcolor_to_tuple(getattr(self, "scoreboard_fg", QColor(255, 255, 255)))
        meta.scoreboard.text_bgcolor = tools.qcolor_to_tuple(getattr(self, "scoreboard_bg", QColor(0, 0, 0, 150)))


        # TODO: coletar outros dados da interface, ex:
        # - scoreboard_image
        # - obstáculos
        # - colecionáveis
        # - funções de velocidade e limites

        save_path = self.get_save_fname("Salvar jogo", "game", suggestion=str(self.path_games))

        if save_path:
            save_meta(meta, save_path)
            QMessageBox.information(self.win, "Sucesso", f"Jogo salvo em:\n{save_path}")
            self.changed = False
            self.ui.action_Save.setEnabled(True)

        self.ui.action_Save.setEnabled(True)

    #--------------------------------------------------------------------------#
    def save_as(self):
        self.file_name = 'get_file_name'
        self.model.save(self.file_name)
        self.changed = False

    #--------------------------------------------------------------------------#
    def exit(self):
        if self.confirm_deletion():
            # Disconnect undo stack signals to avoid callbacks running after widgets
            # have been destroyed during application shutdown. This prevents
            # RuntimeError: Internal C++ object ... already deleted.
            try:
                for stack in getattr(self, 'undo_stacks', []):
                    try:
                        stack.indexChanged.disconnect()
                    except Exception:
                        # ignore if already disconnected or not connected
                        pass
            except Exception:
                pass

            QApplication.quit()

    #--------------------------------------------------------------------------#
    def run(self):
        self.block_ui()
        self.model.update_meta()
        self.model.run()

    #--------------------------------------------------------------------------#
    def build(self):
        # self.exe_file_name = 'get_file_name'
        # self.block_ui()
        # self.model.build( self.exe_file_name )
        pass

    #--------------------------------------------------------------------------#
    def about(self):
        QMessageBox.about(
            self.win,
            parameters.title + ' - About',
            parameters.about
        )

    #--------------------------------------------------------------------------#
    def help(self):
        QMessageBox.about(
            self.win,
            parameters.title + ' - Help',
            parameters.about
        )

    #--------------------------------------------------------------------------#
    # Slots
    #--------------------------------------------------------------------------#

    def select_image(self, folder, label):
        path_backgrounds = self.path_resources / folder
        fname = self.get_open_fname('Escolha uma Imagem', path_backgrounds, 'png')

        if fname:
            new_image = QPixmap(fname) # Tratar exceção

            self.add_image_undo(label, new_image, "Alterar imagem do fundo")
            self.changed = True

    #--------------------------------------------------------------------------#
    def configure_scoreboard_text(self):
        dialog = ScoreboardDialog(self, self.win)
        if dialog.exec():
            self.update_scoreboard_preview()

    #--------------------------------------------------------------------------#
    def update_scoreboard_preview(self):

        preview_text = "Text Example"

        font_path = getattr(self, "scoreboard_font_path", None)
        font_size = getattr(self, "scoreboard_font_size", self.meta.text_font_size or 14)

        fg = getattr(self, "scoreboard_fg", QColor(255, 255, 255))       # branco
        bg = getattr(self, "scoreboard_bg", QColor(0, 0, 0, 150))        # preto semi-transparente

        # Carrega a fonte escolhida (ou volta para Arial se não conseguir)
        if font_path:
            font_id = QFontDatabase.addApplicationFont(font_path)
            if font_id != -1:
                family = QFontDatabase.applicationFontFamilies(font_id)[0]
                font = QFont(family, font_size)
            else:
                font = QFont("Arial", font_size)
        else:
            font = QFont("Arial", font_size)

        #Aplica no label da interface principal
        self.ui.label_ScoreboardExample.setFont(font)
        self.ui.label_ScoreboardExample.setText(preview_text)
        self.ui.label_ScoreboardExample.setStyleSheet(
            f"color: rgba({fg.red()},{fg.green()},{fg.blue()},{fg.alpha()});"
            f"background-color: rgba({bg.red()},{bg.green()},{bg.blue()},{bg.alpha()});"
        )

        self.scoreboard_font = font
        self.scoreboard_font_size = font_size
        self.scoreboard_fg = fg
        self.scoreboard_bg = bg




    #--------------------------------------------------------------------------#
    def select_image_with_spinbox(self, folder, label, spin_width, spin_height):

        path  = self.path_resources / folder
        fname = self.get_open_fname('Escolha uma Imagem', path, 'png')

        old_width  = getattr(spin_width,  "_last_value", "")
        old_height = getattr(spin_height, "_last_value", "")

        if fname:
            new_image = QPixmap(fname)

            self.add_image_spinbox_undo(
                label,
                spin_width,
                spin_height,
                new_image,
                old_width,
                old_height,
                "Alterar imagem do fundo"
            )

            self.changed = True

    #--------------------------------------------------------------------------#
    def select_value_spinbox(self, spin_width, spin_height, label, keep_aspect):
        old_width = getattr(spin_width, "_last_value", "")
        old_height = getattr(spin_height, "_last_value", "")

        self.add_spinBox_undo(spin_width, spin_height, old_width, old_height, label, keep_aspect, "Alterar Valor")

    #--------------------------------------------------------------------------#
    def select_keep_aspect(self, keep, spin_height):
        old_state = getattr(keep, "_last_value", "")
        self.add_keep_aspect_undo(keep, spin_height, old_state, description="Alterar manter proporção")

    #--------------------------------------------------------------------------#
    def select_value(self, spinBox):
        new_value = spinBox.value()
        old_value = getattr(spinBox, "_last_value", spinBox.value())

        if old_value != new_value:
            self.add_value_undo(spinBox, old_value, new_value, "ALterar valor")
        spinBox._last_value = new_value

    #--------------------------------------------------------------------------#
    def select_checked(self, target):
        new_value = target.isChecked()
        old_value = getattr(target, "_last_value", new_value)

        if old_value != new_value:
            self.add_checked_undo(target, old_value, new_value, "Alterar seleção")
        target._last_value = new_value

    #--------------------------------------------------------------------------#
    def change_text(self, widget):
        if isinstance(widget, QPlainTextEdit):
            # Para evitar reset do cursor a cada mudança
            widget._last_text = widget.toPlainText()
            self.changed = True
            return

        new_text = widget.text() if hasattr(widget, 'text') else widget.toPlainText()
        old_text = getattr(widget, '_last_text', '')

        if new_text != old_text:
            self.add_text_undo(self, widget, old_text, new_text, "Alterar texto")
            widget._last_text = new_text
            self.changed = True


    #--------------------------------------------------------------------------#
    def select_ambience_sound(self):
        path_sounds = self.path_resources/'sounds'
        fname = self.get_open_fname('Escolha um som ambiente', path_sounds, 'mp3')

        if fname:
            controller = self
            old_sound=self.model.meta.game_ambience
            new_sound=fname
            old_volume=self.model.meta.game_ambience_volume
            new_volume=self.ui.doubleSpinBox_AmbienceSoundVolume.value()

            self.add_sound_undo(controller, old_sound, new_sound, old_volume, new_volume, "Alterar som ambiente")
            self.changed = True

    #--------------------------------------------------------------------------#
    def ambience_remove(self):
        controller = self
        old_sound=self.model.meta.game_ambience
        new_sound=None
        old_volume=self.model.meta.game_ambience_volume
        new_volume=0.5

        self.add_sound_undo(controller, old_sound, new_sound, old_volume, new_volume, "Remover som ambiente")

        self.audio_manager.stop()
        self.changed = True

    #--------------------------------------------------------------------------#
    def ambience_play(self):
        if hasattr(self.model.meta, 'game_ambience') and self.model.meta.game_ambience:
            volume = self.ui.doubleSpinBox_AmbienceSoundVolume.value()

            # Verifica se é um BytesIO ou um caminho de arquivo
            if isinstance(self.model.meta.game_ambience, BytesIO):
                self.audio_manager.load_sound(self.model.meta.game_ambience)
            else:
                sound_path = self.path_resources / str(self.model.meta.game_ambience)
                self.audio_manager.load_sound(sound_path)

            self.audio_manager.play(loop=True, volume=volume)
            # Agenda para parar a música após 10 segundos (10.000 milissegundos)
            timer = QTimer(self.win)
            timer.setSingleShot(True)
            timer.timeout.connect(self.audio_manager.stop)
            timer.start(10000)
            self.changed = False

    #--------------------------------------------------------------------------#
    def ambience_set_volume(self, volume):
        self.audio_manager.set_volume(volume)
        if hasattr(self.model.meta, 'game_ambience_volume'):
            self.model.meta.game_ambience_volume = volume

    #--------------------------------------------------------------------------#
    def cleanup(self):
        self.audio_manager.cleanup()

    #--------------------------------------------------------------------------#
    def obstacles_frequency_changed(self):
        pass

    #--------------------------------------------------------------------------#
    def collectibles_frequency_changed(self):
        pass

    #--------------------------------------------------------------------------#

    def new_obstacle_widget(self):

        widget = ObjectWidget(self.obstacles_area)

        bar = self.obstacles_area.verticalScrollBar()
        bar.setValue(bar.maximum())

        widget.ui.spinBox_Width._last_value = 1
        widget.ui.spinBox_Height._last_value = 1

        widget.ui.checkBox_KeepAspectRatio._last_value = widget.ui.checkBox_KeepAspectRatio.isChecked()
        widget.ui.doubleSpinBox_Points._last_value = widget.ui.doubleSpinBox_Points.value()
        widget.ui.doubleSpinBox_Volume._last_value = widget.ui.doubleSpinBox_Volume.value()

        #------------------RESOLVER ISSO O MAIS RAPIDO POSSIVEL-----------------------------------------------------#
        widget.ui.spinBox_Width.setMaximum(300)
        widget.ui.spinBox_Height.setMaximum(300)
        #-----------------------------------------------------------------------#

        widget.type = 'obstacle'

        widget.ui.pushButton_SelectImage.clicked.connect(
            lambda :self.select_image_with_spinbox(
                "objects",
                widget.ui.label_Image,
                widget.ui.spinBox_Width,
                widget.ui.spinBox_Height
            )
        )

        widget.ui.spinBox_Width.valueChanged.connect(
            lambda: self.select_value_spinbox(
                widget.ui.spinBox_Width,
                widget.ui.spinBox_Height,
                widget.ui.label_Image,
                widget.ui.checkBox_KeepAspectRatio
            )
        )

        widget.ui.spinBox_Height.valueChanged.connect(
            lambda: self.select_value_spinbox(
                widget.ui.spinBox_Width,
                widget.ui.spinBox_Height,
                widget.ui.label_Image,
                widget.ui.checkBox_KeepAspectRatio
            )
        )

        widget.ui.checkBox_KeepAspectRatio.stateChanged.connect(
            lambda: self.select_keep_aspect(
                widget.ui.checkBox_KeepAspectRatio,
                widget.ui.spinBox_Height
            )
        )

        widget.ui.doubleSpinBox_Points.valueChanged.connect(
            lambda: self.select_value(widget.ui.doubleSpinBox_Points)
        )

        self.add_object_undo(
            widget,
            self.obstacles_box,
            self.num_obstacles,
            "criação de objeto"
        )

        widget.ui.pushButton_Delete.clicked.connect(
            lambda :self.hide_object_widget(
                widget,
                self.obstacles_box,
                self.obstacles_box.indexOf(widget),

            )
        )

        widget.ui.pushButton.clicked.connect(
            lambda :self.duplicate_object(
                widget,
                self.obstacles_box,
                self.obstacles_box.indexOf(widget)+1
            )
        )

        return widget

    #--------------------------------------------------------------------------#
    def new_collectible_widget(self):

        widget = ObjectWidget(self.collectibles_area)

        bar = self.collectibles_area.verticalScrollBar()
        bar.setValue(bar.maximum())

        widget.ui.spinBox_Width._last_value = 1
        widget.ui.spinBox_Height._last_value = 1

        widget.ui.checkBox_KeepAspectRatio._last_value = widget.ui.checkBox_KeepAspectRatio.isChecked()
        widget.ui.doubleSpinBox_Points._last_value = widget.ui.doubleSpinBox_Points.value()
        widget.ui.doubleSpinBox_Volume._last_value = widget.ui.doubleSpinBox_Volume.value()

        widget.type = 'collectible'

        widget.ui.pushButton_SelectImage.clicked.connect(
            lambda :self.select_image_with_spinbox(
                "objects",
                widget.ui.label_Image,
                widget.ui.spinBox_Width,
                widget.ui.spinBox_Height
            )
        )

        widget.ui.spinBox_Width.valueChanged.connect(
            lambda: self.select_value_spinbox(
                widget.ui.spinBox_Width,
                widget.ui.spinBox_Height,
                widget.ui.label_Image,
                widget.ui.checkBox_KeepAspectRatio
            )
        )

        widget.ui.spinBox_Height.valueChanged.connect(
            lambda: self.select_value_spinbox(
                widget.ui.spinBox_Width,
                widget.ui.spinBox_Height,
                widget.ui.label_Image,
                widget.ui.checkBox_KeepAspectRatio
            )
        )

        widget.ui.checkBox_KeepAspectRatio.stateChanged.connect(
            lambda: self.select_keep_aspect(
                widget.ui.checkBox_KeepAspectRatio,
                widget.ui.spinBox_Height
            )
        )

        widget.ui.doubleSpinBox_Points.valueChanged.connect(
            lambda: self.select_value(widget.ui.doubleSpinBox_Points)
        )

        self.add_object_undo(
            widget,
            self.collectibles_box,
            self.num_collectibles,
            "criação de objeto"
        )

        widget.ui.pushButton_Delete.clicked.connect(
            lambda :self.hide_object_widget(
                widget,
                self.collectibles_box,
                self.collectibles_box.indexOf(widget),

            )
        )

        widget.ui.pushButton.clicked.connect(
            lambda :self.duplicate_object(
                widget,
                self.collectibles_box,
                self.collectibles_box.indexOf(widget)+1
            )
        )

        return widget

    #--------------------------------------------------------------------------#

    def hide_object_widget(self, widget, ui, position):
        self.remove_object_undo(widget, ui, position, "remoção de objeto")

    #--------------------------------------------------------------------------#

    def duplicate_object(self, widget, ui, position):

        new_widget = ObjectWidget(self.obstacles_area)
        new_widget.ui.label_Image.setPixmap(widget.ui.label_Image.pixmap())
        new_widget.ui.spinBox_Width.setValue(widget.ui.spinBox_Width.value())
        new_widget.ui.spinBox_Height.setValue(widget.ui.spinBox_Height.value())
        new_widget.ui.checkBox_KeepAspectRatio.setChecked(widget.ui.checkBox_KeepAspectRatio.isChecked())
        new_widget.ui.doubleSpinBox_Points.setValue(widget.ui.doubleSpinBox_Points.value())
        new_widget.ui.doubleSpinBox_Volume.setValue(widget.ui.doubleSpinBox_Volume.value())
        new_widget.sound = widget.sound
        new_widget.type = widget.type

        new_widget.ui.label_Image.setProperty('original_pixmap', widget.ui.label_Image.property('original_pixmap'))
        new_widget.ui.spinBox_Width._last_value = new_widget.ui.spinBox_Width.value()
        new_widget.ui.spinBox_Height._last_value = new_widget.ui.spinBox_Height.value()

        new_widget.ui.checkBox_KeepAspectRatio._last_value = new_widget.ui.checkBox_KeepAspectRatio.isChecked()
        new_widget.ui.doubleSpinBox_Points._last_value = new_widget.ui.doubleSpinBox_Points.value()
        new_widget.ui.doubleSpinBox_Volume._last_value = new_widget.ui.doubleSpinBox_Volume.value()

        new_widget.ui.pushButton_SelectImage.clicked.connect(
            lambda :self.select_image_with_spinbox(
                "objects",
                new_widget.ui.label_Image,
                new_widget.ui.spinBox_Width,
                new_widget.ui.spinBox_Height
            )
        )

        new_widget.ui.spinBox_Width.valueChanged.connect(
            lambda: self.select_value_spinbox(
                new_widget.ui.spinBox_Width,
                new_widget.ui.spinBox_Height,
                new_widget.ui.label_Image,
                new_widget.ui.checkBox_KeepAspectRatio
            )
        )

        new_widget.ui.spinBox_Height.valueChanged.connect(
            lambda: self.select_value_spinbox(
                new_widget.ui.spinBox_Width,
                new_widget.ui.spinBox_Height,
                new_widget.ui.label_Image,
                new_widget.ui.checkBox_KeepAspectRatio
            )
        )

        new_widget.ui.checkBox_KeepAspectRatio.stateChanged.connect(
            lambda: self.select_keep_aspect(
                new_widget.ui.checkBox_KeepAspectRatio,
                new_widget.ui.spinBox_Height
            )
        )

        new_widget.ui.doubleSpinBox_Points.valueChanged.connect(
            lambda: self.select_value(new_widget.ui.doubleSpinBox_Points)
        )

        self.dupicate_object_undo(new_widget, ui, position, "duplicação de objeto")

        new_widget.ui.pushButton_Delete.clicked.connect(lambda :self.hide_object_widget(new_widget, ui, ui.indexOf(new_widget)))

        new_widget.ui.pushButton.clicked.connect(lambda :self.duplicate_object(new_widget, ui, ui.indexOf(new_widget)+1))


    #--------------------------------------------------------------------------#
    def remove_obstacle_widget(self, obj_id):

        item = self.obstacles_box.takeAt(obj_id)
        item.widget().deleteLater()

        self.obstacles.pop(obj_id)
        self.num_obstacles -= 1

    #--------------------------------------------------------------------------#
    def remove_collectible_widget(self, obj_id):

        item = self.collectibles_box.takeAt(obj_id)
        item.widget().deleteLater()

        self.collectibles.pop(obj_id)
        self.num_collectibles -= 1

    #--------------------------------------------------------------------------#
    def change_plainText(self, widget: QPlainTextEdit, description="Alterar texto"):
        new_text = widget.toPlainText()
        old_text = getattr(widget, "_last_text", "")
        if new_text != old_text:
            self.add_text_undo(self, widget, old_text, new_text, description)
            widget._last_text = new_text
            self.changed = True
    #--------------------------------------------------------------------------#
    def function_velocity_changed(self):

        func = self.ui.lineEdit_FunctionVelocity.text()
        old_text = getattr(self.ui.lineEdit_FunctionVelocity, "_last_text", "")


        try:
            self.model.change_velocity_function(func)
            self.plot_velocity.update_velocity(self.model.get_velocity_function())

            self.add_text_undo(self, self.ui.lineEdit_FunctionVelocity, old_text, func, "Alterar velocidade")
            self.ui.lineEdit_FunctionVelocity._last_text = func

        except EvalFunctionError as e:
            QMessageBox.critical(None, "Erro", e.message)
            self.ui.lineEdit_FunctionVelocity.setText(old_text)




    #-------------------------------------------------------------------------#
    def function_track_minimum_changed(self):
        func = self.ui.lineEdit_FunctionTrackMinimum.text()
        old_text = getattr(self.ui.lineEdit_FunctionTrackMinimum, "_last_text", "")

        try:
            self.model.change_track_minimum_function(func)
            self.plot_track.update_boundary(self.model.get_boundary_functions())


            self.add_text_undo(self, self.ui.lineEdit_FunctionTrackMinimum, old_text, func, "Alterar mínimo")
            self.ui.lineEdit_FunctionTrackMinimum._last_text = func

        except EvalFunctionError as f:
            QMessageBox.critical(None, "Erro", f.message)
            self.ui.lineEdit_FunctionTrackMinimum.setText(old_text)


    #--------------------------------------------------------------------------#
    def function_track_maximum_changed(self):
        func = self.ui.lineEdit_FunctionTrackMaximum.text()
        old_text = getattr(self.ui.lineEdit_FunctionTrackMaximum, "_last_text", "")

        try:
            self.model.change_track_maximum_function(func)
            self.plot_track.update_boundary(self.model.get_boundary_functions())


            self.add_text_undo(self, self.ui.lineEdit_FunctionTrackMaximum, old_text, func, "Alterar mínimo")
            self.ui.lineEdit_FunctionTrackMaximum._last_text = func

        except EvalFunctionError as g:
            QMessageBox.critical(None, "Erro", g.message)
            self.ui.lineEdit_FunctionTrackMaximum.setText(old_text)

    #--------------------------------------------------------------------------#

    #--------------------------------------------------------------------------#
    # Internal tasks
    #--------------------------------------------------------------------------#

    #--------------------------------------------------------------------------#
    def start_new(self):
        self.model.new()
        self.start_view_from_model()

    #--------------------------------------------------------------------------#
    def start_view_from_model(self):

        self.ui.tabWidget_Game   .setCurrentIndex(0)
        self.ui.tabWidget_Objects.setCurrentIndex(0)

        self.ui.doubleSpinBox_AmbienceSoundVolume.setEnabled(False)
        self.model.update_ui()

        self.plot_velocity.update_velocity(
            self.model.get_velocity_function()
        )
        self.plot_track.update_boundary(
            self.model.get_boundary_functions()
        )

        # --- Config do Scoreboard via diálogo ---
        font_data = self.meta.text_font
        font_size = self.meta.text_font_size or 14

        if font_data:
            font = tools.bytes_to_qfont(font_data, font_size)
        else:
            font = QFont("Arial", font_size)

        self.ui.label_ScoreboardExample.setFont(font)

        # Cores vindas do meta
        fg = self.meta.text_fgcolor or (255, 255, 255, 255)   # branco
        bg = self.meta.text_bgcolor or (0, 0, 0, 150)        # preto semi-transparente

        self.scoreboard_fg = QColor(*fg)
        self.scoreboard_bg = QColor(*bg)

        self.update_scoreboard_preview()
        self.changed = False

    #--------------------------------------------------------------------------#
    def confirm_deletion(self):

        # TODO: implementar um quadro de dialogo confirmando a destruição
        #       das alterações não salvas

        # if self.changed:
        #     return False
        return True

    #--------------------------------------------------------------------------#
    def block_ui(self):
        pass

    #--------------------------------------------------------------------------#
    def clear_obstacle_widgets(self):
        nn = self.num_obstacles
        for _ in range(nn):
            self.remove_obstacle_widget(0)

    #--------------------------------------------------------------------------#
    def clear_collectible_widgets(self):
        nn = self.num_collectibles
        for _ in range(nn):
            self.remove_collectible_widget(0)

    #--------------------------------------------------------------------------#
    # Tools
    #--------------------------------------------------------------------------#

    #--------------------------------------------------------------------------#
    def error_box( self, title, message ):
        QMessageBox.critical( self.win, title, message,
                              buttons=QMessageBox.StandardButton.Ok )

    #--------------------------------------------------------------------------#
    def get_open_fname( self, title, path, ext ):
        fname, _ = QFileDialog.getOpenFileName( parent  = self.win,
                                                caption = title,
                                                dir     = str(path),
                                                filter  = '*.' + ext )
        return fname

    #--------------------------------------------------------------------------#
    def get_save_fname( self, title, ext, suggestion = '' ):

        if not suggestion:
            suggestion = self.last_dir

        fname, _ = QFileDialog.getSaveFileName( parent  = self.win,
                                                caption = title,
                                                dir     = suggestion,
                                                filter  = '*.' + ext )
        if fname:
            ee = '.' + ext
            nn = len(ee)
            if len(fname) < nn or fname[-nn:] != ee:
                fname += ee

        return fname
    #--------------------------------------------------------------------------#
    def add_image_undo(self, label, new_image, description):
        command = undo.ChangeImageCommand(label, new_image, description)
        stack = self.undo_group.activeStack()
        stack.push(command)

    #--------------------------------------------------------------------------#
    def add_image_spinbox_undo(
            self,
            label,
            spin_width,
            spin_height,
            new_image,
            old_width,
            old_height,
            description
        ):

        command = undo.ChangeSpinBoxImageCommand(
            label,
            spin_width,
            spin_height,
            new_image,
            old_width,
            old_height,
            description
        )

        stack = self.undo_group.activeStack()
        stack.push(command)

    #--------------------------------------------------------------------------#
    def add_keep_aspect_undo(self, keep, spin_height, old_state, description):
        command = undo.ChangeKeepImageCommand(keep, spin_height, old_state, description)
        stack = self.undo_group.activeStack()
        stack.push(command)

    #--------------------------------------------------------------------------#
    def add_spinBox_undo(self, spin_width, spin_height, old_width, old_height, label, keep_aspect, description):
        command = undo.ChangeSpinBoxValueCommand(spin_width, spin_height, old_width, old_height, label, keep_aspect, description)
        stack = self.undo_group.activeStack()
        stack.push(command)
    #--------------------------------------------------------------------------#
    def add_value_undo(self, target, old_value, new_value, description):
        command = undo.ChangeValueCommand(target, old_value, new_value, self, description)
        stack = self.undo_group.activeStack()
        stack.push(command)

    #--------------------------------------------------------------------------#
    def add_checked_undo(self, target, old_value, new_value, description):
        command = undo.ChangeCheckedCommand(target, old_value, new_value, self, description)
        stack = self.undo_group.activeStack()
        stack.push(command)

     #--------------------------------------------------------------------------#
    def add_sound_undo(self, controller, old_sound, new_sound, old_volume, new_volume, description):
        command = undo.ChangeSoundCommand(controller, old_sound, new_sound, old_volume, new_volume, description)
        stack = self.undo_group.activeStack()
        stack.push(command)

    #--------------------------------------------------------------------------#
    def add_text_undo(self, controller, widget, old_text, new_text, description):
        command = undo.ChangeTextCommand(controller, widget, old_text, new_text, description)
        stack = self.undo_group.activeStack()
        stack.push(command)
    #--------------------------------------------------------------------------#
    def add_object_undo(self,new_object, ui, position, description):
        command = undo.AddObjectCommand(new_object, ui, position, self, description)
        stack = self.undo_group.activeStack()
        stack.push(command)

    #--------------------------------------------------------------------------#
    def remove_object_undo(self,new_object, ui, position, description):
        command = undo.HideObjectCommand(new_object, ui, position, self, description)
        stack = self.undo_group.activeStack()
        stack.push(command)

    #--------------------------------------------------------------------------#
    def dupicate_object_undo(self,new_object, ui, position, description):
        command = undo.AddObjectCommand(new_object, ui, position, self, description)
        stack = self.undo_group.activeStack()
        stack.push(command)

     #--------------------------------------------------------------------------#
    def add_scoreboard_text_undo(self, attr_name, old_value, new_value, description):
        command = undo.ChangeScoreboardTextCommand(self, attr_name, old_value, new_value, description)
        stack = self.undo_group.activeStack()
        stack.push(command)


    #--------------------------------------------------------------------------#
    def clear_stacks_undo(self):
        for i in range(self.ui.tabWidget_Game.count()):
            self.undo_stacks[i].clear()

 #---------------------------------------------------------------------------#
    def update_tracks_undo(self):
        # Defensive: widgets may be deleted during shutdown; catch RuntimeError
        try:
            func1 = self.ui.lineEdit_FunctionTrackMaximum.text()
            func2 = self.ui.lineEdit_FunctionTrackMinimum.text()

            self.model.change_track_minimum_function(func2)

            self.model.change_track_maximum_function(func1)
            self.plot_track.update_boundary(
                self.model.get_boundary_functions()
            )
            self.ui.lineEdit_FunctionTrackMaximum._last_text = func1
            self.ui.lineEdit_FunctionTrackMinimum._last_text = func2
        except RuntimeError:
            # Qt object already deleted during shutdown; ignore
            return
        except Exception:
            # Keep other exceptions visible for debugging but avoid crashing
            return
    #--------------------------------------------------------------------------#

    def update_velocity_undo(self):
        try:
            func = self.ui.lineEdit_FunctionVelocity.text()

            self.model.change_velocity_function(func)
            self.plot_velocity.update_velocity(
                self.model.get_velocity_function()
            )
            self.ui.lineEdit_FunctionVelocity._last_text = func
        except RuntimeError:
            # Qt object already deleted during shutdown; ignore
            return
        except Exception:
            return
 #---------------------------------------------------------------------------#



    # Configurar para programar
    def update_data(self):
        #---------------ABA GERAL-------------------#

        # Inicializa os valores dos textos para undo/redo
        widgets = [(self.ui.lineEdit_GameName, self.model.meta.soft_name), (self.ui.lineEdit_Author, self.model.meta.soft_author),(self.ui.plainTextEdit_GameDescription, self.model.meta.soft_description),
                   (self.ui.lineEdit_FunctionVelocity, self.model.meta.velocity.get_function_orig()), (self.ui.lineEdit_FunctionTrackMinimum, self.model.meta.boundary.get_function_min_orig()),
                   (self.ui.lineEdit_FunctionTrackMaximum, self.model.meta.boundary.get_function_max_orig())]
        for widget, default in widgets:
            widget._last_text = default

        #Atualiza os atributos das widget da aba geral
        self.ui.doubleSpinBox_AmbienceSoundVolume._last_value = self.ui.doubleSpinBox_AmbienceSoundVolume.value()
        self.ui.doubleSpinBox_ScoreTimeBonus._last_value = self.ui.doubleSpinBox_ScoreTimeBonus.value()
        self.ui.checkBox_TrackMaximumKills._last_value = self.ui.checkBox_TrackMaximumKills.isChecked()
        self.ui.checkBox_TrackMinimumKills._last_value = self.ui.checkBox_TrackMinimumKills.isChecked()
        self.ui.radioButton_HorizontalScrolling._last_value = self.ui.radioButton_HorizontalScrolling.isChecked()
        self.ui.radioButton_VerticalScrolling._last_value = self.ui.radioButton_VerticalScrolling.isChecked()

        #---------------ABA APARÊNCIA-------------------#

        # Variaveis da aba aparencia
        self.scoreboard_positionX = self.ui.spinBox_ScoreboardImagePositionX.value()
        self.scoreboard_positionY = self.ui.spinBox_ScoreboardImagePositionY.value()
        self.scoreboard_imageWidth = self.ui.spinBox_ScoreboardImageWidth.value()
        self.scoreboard_imageHeight = self.ui.spinBox_ScoreboardImageHeight.value()
        self.background_scrolls = self.ui.checkBox_BackgroundImageScrolls.isChecked()
        self.draw_track = self.ui.checkBox_DrawTrack.isChecked()

        #Atualiza os atributos das widget da aba aparencia
        self.ui.spinBox_ScoreboardImageHeight.setEnabled(False)
        self.ui.spinBox_ScoreboardImagePositionX._last_value = self.scoreboard_positionX
        self.ui.spinBox_ScoreboardImagePositionY._last_value = self.scoreboard_positionY
        self.ui.spinBox_ScoreboardImageWidth._last_value = self.scoreboard_imageWidth
        self.ui.spinBox_ScoreboardImageHeight._last_value = self.scoreboard_imageHeight
        self.ui.checkBox_BackgroundImageScrolls._last_value = self.background_scrolls
        self.ui.checkBox_DrawTrack._last_value = self.draw_track

        #---------------ABA OBJETOS-------------------#

        # Variaveis da aba player
        self.player_width       = self.ui.spinBox_PlayerWidth.value()
        self.player_height      = self.ui.spinBox_PlayerHeight.value()
        self.player_speed       = self.ui.spinBox_PlayerSpeed.value()
        self.player_keep_aspect = self.ui.checkBox_PlayerKeepAspectRatio.isChecked()
        self.obstacles_frequency = self.ui.doubleSpinBox_ObstaclesFrequency.value()
        self.collectibles_frequency = self.ui.doubleSpinBox_CollectiblesFrequency.value()

        #Atualiza os atributos das widget da aba Objetos
        self.ui.spinBox_PlayerHeight.setEnabled(False)
        self.ui.spinBox_PlayerWidth._last_value = self.player_width
        self.ui.spinBox_PlayerHeight._last_value = self.player_height
        self.ui.spinBox_PlayerSpeed._last_value = self.player_speed
        self.ui.checkBox_PlayerKeepAspectRatio._last_value = self.player_keep_aspect
        self.ui.doubleSpinBox_ObstaclesFrequency._last_value = self.obstacles_frequency
        self.ui.doubleSpinBox_CollectiblesFrequency._last_value = self.collectibles_frequency

        for i in range(self.num_obstacles):
            obj = self.obstacles_box.itemAt(i).widget()

            obj.ui.spinBox_Width._last_value = obj.ui.spinBox_Width.value()
            obj.ui.spinBox_Height._last_value = obj.ui.spinBox_Height.value()
            obj.ui.checkBox_KeepAspectRatio._last_value = obj.ui.checkBox_KeepAspectRatio.isChecked()
            obj.ui.doubleSpinBox_Points._last_value = obj.ui.doubleSpinBox_Points.value()
            obj.ui.doubleSpinBox_Volume._last_value = obj.ui.doubleSpinBox_Volume.value()


#------------------------------------------------------------------------------#
